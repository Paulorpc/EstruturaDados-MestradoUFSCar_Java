package Ex6;

public class ListaEncadeada {
	
	private Node cabeca;
	private Node cauda;
	private int tamanho;
	
	public ListaEncadeada() {
		cabeca = null;
		cauda = null;
		tamanho = 0;		
	}
	
	public ListaEncadeada(Node n) {
		cabeca = n;
		tamanho++;
	}

	public Node getCabeca() {
		return cabeca;
	}

	public Node getCauda() {
		return cauda;
	}

	public int getTamanho() {
		return tamanho;
	}
	
	public void adicionaInicio(Node n) {
		
		if (tamanho == 0) {
			cabeca = cauda = n;
		}
		else {
			n.setNext(cabeca);
			cabeca = n;
		}
		tamanho++;
	}
		
		
	public void adicionaFim(Node n) {
		
		if(tamanho == 0) {
			adicionaInicio(n);
		}
		else {
			n.setNext(null);
			cauda.setNext(n);
			cauda = n;
			tamanho++;
		}
	}
	
	public Node removeInicio() throws Exception {
		
		if(tamanho == 0)
			throw new Exception("Lista já está vazia.");
		
		Node cabecaRemovida = cabeca;
		cabeca = cabeca.getNext();
		cabecaRemovida.setNext(null);
		tamanho--;
		
		return cabecaRemovida;		
	}
	
	public void printCabeca() throws Exception {
		
		if (tamanho == 0)
			throw new Exception("Lista vazia.");
		
		System.out.println("[ Cabeça ]");
		getCabeca().printNode();
		
	}

	public void printCauda() throws Exception {		
		
		if (cauda == null)
			throw new Exception("Lista vazia.");
		
		System.out.println("[ Cauda ]");
		getCauda().printNode();
	}
}
